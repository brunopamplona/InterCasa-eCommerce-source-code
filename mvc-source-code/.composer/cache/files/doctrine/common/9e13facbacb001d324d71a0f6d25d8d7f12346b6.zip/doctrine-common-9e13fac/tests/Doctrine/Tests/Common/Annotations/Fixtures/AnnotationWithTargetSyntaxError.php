<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures;

/**
 * @Annotation
 * @Target(@)
 */
final class AnnotationWithTargetSyntaxError
{
}