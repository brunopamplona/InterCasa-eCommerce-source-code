<?php
require_once(dirname(__FILE__) . '/../../autorun.php');
?>