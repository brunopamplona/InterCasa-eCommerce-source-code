<?php
class TestFile
{
    public function __construct()
    {
        $this->message = 'hoge';
    }
}
