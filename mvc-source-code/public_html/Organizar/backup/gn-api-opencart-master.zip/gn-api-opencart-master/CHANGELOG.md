# v0.3.1

* Delete: Obrigatoriedade de CPF para compras de Pessoa Jurídica.
* Add: Validação de moeda utilizada.

# v0.3.0

* Add: Unificação do módulo único para todas versões 2.x
* Add: Configuração das instruções do boleto bancário

# v0.2.0

* Fix: Validações
* Add: Finalizar compra em um passo.

# v0.1.1

* Fix: Pagar cobrança com CNPJ.
* Fix: Layout bug.
* Fix: Validação dos campos.

# v0.1.0

* Versão Beta